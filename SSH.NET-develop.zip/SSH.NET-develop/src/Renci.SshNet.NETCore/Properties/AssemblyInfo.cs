﻿using System.Reflection;

[assembly: AssemblyTitle("SSH.NET")]
