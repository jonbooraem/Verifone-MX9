﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Renci.SshNet.Tests.Common;

namespace Renci.SshNet.Tests.Classes.Common
{
    /// <summary>
    /// Base class forTest : TestBaseall channel related events.
    /// </summary>
    [TestClass]
    public class ChannelEventArgsTest : TestBase
    {
    }
}