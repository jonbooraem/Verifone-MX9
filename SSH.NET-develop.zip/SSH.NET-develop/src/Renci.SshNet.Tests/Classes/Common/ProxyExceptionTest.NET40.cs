﻿using Renci.SshNet.Tests.Common;

namespace Renci.SshNet.Tests.Classes.Common
{
    public partial class ProxyExceptionTest : TestBase
    {
    }
}