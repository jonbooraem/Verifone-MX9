﻿using Renci.SshNet.Security;
using Renci.SshNet.Tests.Common;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Renci.SshNet.Tests
{
    /// <summary>
    ///This is a test class for KeyExchangeTest and is intended
    ///to contain all KeyExchangeTest Unit Tests
    ///</summary>
    [TestClass()]
    public class KeyExchangeTest : TestBase
    {

    }
}
