﻿using Renci.SshNet.Messages.Connection;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using Renci.SshNet.Tests.Common;

namespace Renci.SshNet.Tests.Classes.Messages.Connection
{
    /// <summary>
    ///This is a test class for ChannelExtendedDataMessageTest and is intended
    ///to contain all ChannelExtendedDataMessageTest Unit Tests
    ///</summary>
    [TestClass]
    public class ChannelExtendedDataMessageTest : TestBase
    {
        /// <summary>
        ///A test for ChannelExtendedDataMessage Constructor
        ///</summary>
        [TestMethod]
        [Ignore] // placeholder
        public void ChannelExtendedDataMessageConstructorTest()
        {
            ChannelExtendedDataMessage target = new ChannelExtendedDataMessage();
            Assert.Inconclusive("TODO: Implement code to verify target");
        }

        /// <summary>
        ///A test for ChannelExtendedDataMessage Constructor
        ///</summary>
        [TestMethod]
        [Ignore] // placeholder
        public void ChannelExtendedDataMessageConstructorTest1()
        {
            uint localChannelNumber = 0; // TODO: Initialize to an appropriate value
            //ChannelExtendedDataMessage target = new ChannelExtendedDataMessage(localChannelNumber, null, null);
            Assert.Inconclusive("TODO: Implement code to verify target");
        }
    }
}
