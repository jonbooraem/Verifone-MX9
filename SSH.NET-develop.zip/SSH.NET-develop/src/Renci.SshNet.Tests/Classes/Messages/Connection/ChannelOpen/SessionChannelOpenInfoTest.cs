﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Renci.SshNet.Tests.Common;

namespace Renci.SshNet.Tests.Classes.Messages.Connection
{
    /// <summary>
    /// Used to open "session" channel type
    /// </summary>
    [TestClass]
    public class SessionChannelOpenInfoTest : TestBase
    {
    }
}