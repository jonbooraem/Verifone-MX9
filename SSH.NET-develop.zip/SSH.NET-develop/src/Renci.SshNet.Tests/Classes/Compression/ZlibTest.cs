﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Renci.SshNet.Tests.Common;

namespace Renci.SshNet.Tests.Classes.Compression
{
    /// <summary>
    /// Represents "zlib" compression implementation
    /// </summary>
    [TestClass]
    public class ZlibTest : TestBase
    {
    }
}