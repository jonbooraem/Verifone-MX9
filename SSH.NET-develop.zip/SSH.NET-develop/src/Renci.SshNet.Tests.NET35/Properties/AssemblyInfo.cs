﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("SSH.NET Tests .NET 3.5")]
[assembly: Guid("7c827904-40c1-4fe3-8ed1-8a729b8417a9")]